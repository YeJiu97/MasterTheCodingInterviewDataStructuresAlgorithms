//console.log 'goodbye'
function goodBye() {
    console.log('');
}

goodBye();