function goodBye() {
    console.log('goodbye');
}

goodBye();